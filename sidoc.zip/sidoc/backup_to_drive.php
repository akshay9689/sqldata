<?php
require 'vendor/autoload.php';

use Google\Client;
use Google\Service\Drive;

// Database credentials
$dbHost = "localhost";
$dbUser = "admindb";
$dbPass = "5lDw0HY0nMQRphsf3XrH";
$dbName = "earningfishdb";

// home/earningfish-dashboard/htdocs/dashboard.earningfish.com

// Backup file path
$backupDir = "/home/earningfish-dashboard/htdocs/dashboard.earningfish.com/sqldata/backup";
$backupFile = $backupDir . "db_backup_" . date("Y-m-d") . ".sql";

// Ensure backup directory exists
if (!file_exists($backupDir)) {
    mkdir($backupDir, 0777, true);
}

// Create MySQL backup
$command = "mysqldump -h $dbHost -u $dbUser -p'$dbPass' $dbName > $backupFile";
exec($command);

// Compress the backup file
$zipFile = $backupFile . ".gz";
exec("gzip -c $backupFile > $zipFile");
unlink($backupFile); // Delete uncompressed file

// Authenticate with Google Drive API
$client = new Client();
$client->setAuthConfig('credentials.json'); // Your Google API credentials
$client->addScope(Drive::DRIVE_FILE);
$client->setAccessType('offline');

// Get Google Drive service
$service = new Drive($client);

// Upload file to Google Drive
$file = new Drive\DriveFile();
$file->setName(basename($zipFile));
$file->setParents(["your_drive_folder_id"]); // Replace with your Google Drive folder ID

$content = file_get_contents($zipFile);
$uploadedFile = $service->files->create($file, [
    'data' => $content,
    'mimeType' => 'application/gzip',
    'uploadType' => 'multipart'
]);

// Get Google Drive file link
$fileId = $uploadedFile->getId();
$driveLink = "https://drive.google.com/file/d/$fileId/view?usp=sharing";

// Send email with backup link
$to = "your_email@example.com";
$subject = "Database Backup Link - " . date("Y-m-d");
$message = "Your database backup is available at: " . $driveLink;
$headers = "From: your_email@example.com\r\nContent-Type: text/plain; charset=UTF-8";

mail($to, $subject, $message, $headers);

// Delete old backups (older than 7 days)
exec("find $backupDir -type f -name '*.gz' -mtime +7 -delete");

echo "Backup uploaded & email sent successfully!";
?>
